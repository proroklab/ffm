notices = {
    "0.22.0": "",
    "0.23.0": "",
    "0.23.1": "",
    "0.24.0": "Warning: Gym version v0.24.0 has a number of critical issues with `gym.make` such that the `reset` and `step` functions are called before returning the environment. It is recommend to downgrading to v0.23.1 or upgrading to v0.25.1",
    "0.24.1": "Warning: Gym version v0.24.1 has a number of critical issues with `gym.make` such that environment observation and action spaces are incorrectly evaluated, raising incorrect errors and warning . It is recommend to downgrading to v0.23.1 or upgrading to v0.25.1",
    "0.25.0": "",
    "0.25.1": "",
}
