import gym

class CompatibilityWrapper(gym.Wrapper):
    def __init__(self, env):

    def step(self, action):
        return 
